def create_supplier():
	print "this is supplier creation"
create_supplier()