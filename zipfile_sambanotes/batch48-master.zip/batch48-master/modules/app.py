import sales
sales.create_customer()
print sales.a
print sales.b
print sales.c