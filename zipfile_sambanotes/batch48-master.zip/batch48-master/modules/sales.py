a=10
b=20
c=a+b
def create_customer():
	print "this is customer creation"

create_customer()